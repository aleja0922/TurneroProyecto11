
package modelo;


public class Modulo {
    
    private String num_modulo;
    private String cod_servicio;
    private String estado;
    
    
    public Modulo(){
        num_modulo=" ";
        cod_servicio=" ";
        estado="";
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    /**
     * @return the num_modulo
     */
    public String getNum_modulo() {
        return num_modulo;
    }

    /**
     * @param num_modulo the num_modulo to set
     */
    public void setNum_modulo(String num_modulo) {
        this.num_modulo = num_modulo;
    }

    /**
     * @return the cod_servicio
     */
    public String getCod_servicio() {
        return cod_servicio;
    }

    /**
     * @param cod_servicio the cod_servicio to set
     */
    public void setCod_servicio(String cod_servicio) {
        this.cod_servicio = cod_servicio;
    }
    
}
