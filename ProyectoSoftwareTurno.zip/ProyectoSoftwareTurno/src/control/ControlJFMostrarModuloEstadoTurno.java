
package control;
import modelo.*;
import vista.*;
import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import control.BD;
import vista.JFModuloEstadoTurno;

public class ControlJFMostrarModuloEstadoTurno {
    
    
    
}
