
package modelo;


public class Inico_Sesion {
    private String usuario, contraseña, id_Asesor;
    
    public Inico_Sesion (){
        usuario="";
        contraseña="";
        id_Asesor="";
    }

    public String getId_Asesor() {
        return id_Asesor;
    }

    public void setId_Asesor(String id_Asesor) {
        this.id_Asesor = id_Asesor;
    }

    
    /**
     * @return the usuario
     */
    public String getUsuario() {
        return usuario;
    }

    /**
     * @param usuario the usuario to set
     */
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    /**
     * @return the contraseña
     */
    public String getContraseña() {
        return contraseña;
    }

    /**
     * @param contraseña the contraseña to set
     */
    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    
}
