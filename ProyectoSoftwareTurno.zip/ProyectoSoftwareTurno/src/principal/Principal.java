
package principal;
import vista.*;
import control.*;
import java.sql.SQLException;
public class Principal {
    public static void main(String[] args) {
         
    JFPrincipal jp=new JFPrincipal();
    ControlJFPrincipal cjfmturno=new ControlJFPrincipal(jp);
    
    jp.setVisible(true);
        jp.setLocationRelativeTo(null); //centrar ventana


 
    }
}
