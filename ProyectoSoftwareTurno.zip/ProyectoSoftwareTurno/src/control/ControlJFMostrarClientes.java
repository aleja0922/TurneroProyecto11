package control;

import java.awt.event.*;
import javax.swing.table.DefaultTableModel;
import vista.*;
import java.sql.*;



public class ControlJFMostrarClientes implements ActionListener {
    JFMostrarCliente m;
    @SuppressWarnings("LeakingThisInConstructor")
    public ControlJFMostrarClientes(JFMostrarCliente m) {
        this.m = m;
       m.Bmostrarclientes.addActionListener(this);
        m.Bcerrartablaclientes.addActionListener(this);
    }

    @Override
    
    public void actionPerformed(ActionEvent e) {

        BD bd = new BD();
        ResultSet registro;

        DefaultTableModel modelo = new DefaultTableModel();
        if (e.getSource() == m.Bmostrarclientes) {

            // Son las etiquetas de las columnas
            modelo.addColumn("cedula");
            modelo.addColumn("nombre");
              modelo.addColumn("apellido");
              modelo.addColumn("fechanac");
                modelo.addColumn("telefono");
                  modelo.addColumn("direccion");
                    modelo.addColumn("email");
                     modelo.addColumn("estrato");
                      modelo.addColumn("ciudad");
                        modelo.addColumn("discapacidad");
                      modelo.addColumn("estado");
                    
                      
            
            try {
                 bd.conectar();
                registro = bd.hacerConsulta("select cedula_cliente, nombre_cliente,apellido_cliente,fecha_nac_cliente,telefono_cliente,direccion_cliente,email_cliente,estrato_cliente,ciudad_cliente,discapacidad_cliente,estado_cliente from clientes");

                while (registro.next()) {
                    modelo.addRow(new String[]{
                        "" + registro.getString("cedula_cliente"),
                        "" + registro.getString("nombre_cliente"),
                        "" + registro.getString("apellido_cliente"),
                        "" + registro.getString("fecha_nac_cliente"),
                        "" + registro.getString("telefono_cliente"),
                        "" + registro.getString("direccion_cliente"),
                        "" + registro.getString("email_cliente"),
                        "" + registro.getString("estrato_cliente"),
                        "" + registro.getString("ciudad_cliente"),
                        "" + registro.getString("discapacidad_cliente"),
                        "" + registro.getString("estado_cliente")
                        
                        
                        
                        
                    });
                }

                bd.desconectar();
             m.Tablaclientes.setModel(modelo);

            } catch (SQLException error) {
                System.out.println("ERROR EN CONSULTA: " + error);
            }

        }
        
        if(e.getSource()==m.Bcerrartablaclientes){
            m.dispose();
        }
    }

}
