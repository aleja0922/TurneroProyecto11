package control;

import java.awt.event.*;
import java.sql.*;
import control.BD;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.*;
import vista.*;

public class ControlJFIngresoAsesor implements ActionListener {

    BD cn;
    JFIngresoAsesor jflogin;
    Inico_Sesion login;

    @SuppressWarnings("LeakingThisInConstructor")
    public ControlJFIngresoAsesor( JFIngresoAsesor jfloguin) {

        cn = new BD();
        
        this.jflogin = jfloguin;

        jfloguin.BIngresar.addActionListener(this);
        jfloguin.BSalir.addActionListener(this);

    }

    @Override

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == jflogin.BSalir) {
            jflogin.dispose();

        }
        if (e.getSource() == jflogin.BIngresar) {
            System.out.println(jflogin.TUsuario.getText()+"-"+jflogin.TContraseña.getText());
            Inico_Sesion estadoLogueo = validarLogin(jflogin.TUsuario.getText(), jflogin.TContraseña.getText());

            if (estadoLogueo != null) {
                JFRegistroHome jhome = new JFRegistroHome(estadoLogueo);
                ControlJFRegistroHome cjhome = new ControlJFRegistroHome(jhome);
                jhome.setVisible(true);
                jhome.setLocationRelativeTo(null);

            } else {
                IO.mostrar("Usuario no existe");
            }
        }
    }

    public Inico_Sesion validarLogin(String user, String password) {
        Inico_Sesion inico_Sesion = null;
        try {
            String sql = "select * from inicio_sesion where upper(login) = '" + user.toUpperCase() + "' and password = '" + password + "' ";
            cn.conectar();
            cn.getBD(sql);
            if(cn.getRegistro().next()){
                System.out.println("Entro");
                inico_Sesion= new Inico_Sesion();
                inico_Sesion.setUsuario(cn.getRegistro().getString("LOGIN"));
                inico_Sesion.setId_Asesor(cn.getRegistro().getString("ID_ASESOR"));
            }

            cn.CerrarConexion();
            return inico_Sesion;
        } catch (Exception e) {
            return inico_Sesion;
        }

    }
}
