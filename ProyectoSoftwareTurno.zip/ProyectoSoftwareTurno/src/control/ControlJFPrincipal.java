package control;

import modelo.*;
import vista.*;
import vista.JFPrincipal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlJFPrincipal implements ActionListener {

    JFPrincipal jp;

    
    JFIngresoAsesor jfloguin = new JFIngresoAsesor();

    @SuppressWarnings("LeakingThisInConstructor")
    public ControlJFPrincipal(JFPrincipal jp) {

        this.jp = jp;

        jp.Bturno.addActionListener(this);
        jp.Bsesionempleado.addActionListener(this);
        jp.Bsalir.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == jp.Bturno) {

            JFAsignacionTurno jfturno = new JFAsignacionTurno();
            ControlAsignacionTurno ct = new ControlAsignacionTurno(jfturno);
            jfturno.setVisible(true);
            jfturno.setLocationRelativeTo(null);
        }
        if (e.getSource() == jp.Bsesionempleado) {
            ControlJFIngresoAsesor casesor = new ControlJFIngresoAsesor( jfloguin);
            jfloguin.setVisible(true);
            jfloguin.setLocationRelativeTo(null);

        }

        if (e.getSource() == jp.Bsalir) {
            System.exit(0);
        }

    }
}
