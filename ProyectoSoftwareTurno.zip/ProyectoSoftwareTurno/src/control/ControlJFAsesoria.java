package control;

import vista.JFAsesoria;
import java.awt.event.*;
import java.sql.*;
import control.BD;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import control.ControlJFAsesoria;
import vista.JFAsignacionTurno;
import control.ControlAsignacionTurno;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.Timer;
import java.text.DateFormat;


import modelo.*;
import vista.*;

public class ControlJFAsesoria implements ActionListener {
    BD cn;
    private int ABasica;
    private int AGeneral;
    private int ab;
    private int ag;
    JFAsesoria jfa;
    JFMostrarTurno jmc = new JFMostrarTurno();
    
    JFAsignacionTurno jfturno;
    

    @SuppressWarnings("LeakingThisInConstructor")

    public ControlJFAsesoria(JFAsesoria jfa) {
        cn = new BD();

       this.jfa = jfa;
       this.ab=ab;   
       this.ag=ag;
       
       
        jfa.BAbasica.addActionListener(this);
        jfa.BAgeneral.addActionListener(this);
        jfa.BvolverAsignacionA.addActionListener(this);
      
        

    }

   
    @Override
    public void actionPerformed(ActionEvent ae) {
       
        if (ae.getSource() == jfa.BAbasica) {
            
        ControlJFMostrarTurno cmc = new ControlJFMostrarTurno(jmc);
            jmc.setVisible(true);
            jmc.setLocationRelativeTo(null);
//           
             

            String secuencia="";
            ab=ab+1;
            secuencia=  "" + ab;
            
            jmc.TxtidCajaturno.setText(secuencia);

            String myDate = "";
            String AsesoriaBasica = " ";
            String cadena = "AB";
            ABasica = ABasica+ 1;

            AsesoriaBasica = ("AB" + ABasica);

            jmc.Txtrecibirturno.setText((AsesoriaBasica));

            Date sistFecha = new Date();
            SimpleDateFormat formato = new SimpleDateFormat("dd MMMM YYYY");
            jmc.Tfecha.setText(formato.format(sistFecha));

            Date sistHora = new Date();
            String pmAm = "hh : mm :  ss a";
            SimpleDateFormat format = new SimpleDateFormat(pmAm);
            Calendar hoy = Calendar.getInstance();
            jmc.Thora.setText(String.format(format.format(sistHora), hoy));

            
        }
        if (ae.getSource() == jfa.BAgeneral) {
            
            ControlJFMostrarTurno cmc = new ControlJFMostrarTurno(jmc);
            jmc.setVisible(true);
            jmc.setLocationRelativeTo(null);
   
            
             String secuencia="";
            ag=ag+1;
            secuencia=  "" + ag;
            
            jmc.TxtidCajaturno.setText(secuencia);
            

            String myDate = "";
            String AsesoriaGeneral = " ";
            String cadena = "AG";
            AGeneral = AGeneral+ 1;

            AsesoriaGeneral = ("AG" + AGeneral);

            jmc.Txtrecibirturno.setText((AsesoriaGeneral));

            Date sistFecha = new Date();
            SimpleDateFormat formato = new SimpleDateFormat("dd MMMM YYYY");
            jmc.Tfecha.setText(formato.format(sistFecha));

            Date sistHora = new Date();
            String pmAm = "hh : mm :  ss a";
            SimpleDateFormat format = new SimpleDateFormat(pmAm);
            Calendar hoy = Calendar.getInstance();
            jmc.Thora.setText(String.format(format.format(sistHora), hoy));
        
            
          
        }
        if (ae.getSource() == jfa.BvolverAsignacionA) {
            jfa.dispose();
    }
}
}                

           
            
                           
            
            
            

        
    
    

