package control;

import modelo.*;
import vista.*;
import vista.JFAsignacionTurno;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class ControlJFModuloEstadoTurno implements ActionListener {

    BD cn = new BD();
    JFModuloEstadoTurno js;

    Turno turno = new Turno();

    @SuppressWarnings("LeakingThisInConstructor")

    ControlJFModuloEstadoTurno(JFModuloEstadoTurno js) {
        this.js = js;
        this.cn = cn;
        js.setModulo(getCurrentModule(js.getAsesor().getId_Asesor()));
        validarCurrentActual();

        js.BLiberar.addActionListener(this);
        js.BTurnonext.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == js.BLiberar) {
            ControlAsignacionTurno ct = new ControlAsignacionTurno();
            ct.updateEstadoModulo("LIBRE", js.getModulo().getNum_modulo());
            updateTurnoFree(js.TxtTurnocliente.getText());
            validarCurrentActual();
            
        }
//Actualizar
        if (e.getSource() == js.BTurnonext) {

            if (!validarCurrentActual()) {
                List<Turno> listTurnosPrioritarios = getListPrioritarioByServicio(js.getModulo());
                List<Turno> listTurnosNoPrioritarios = getListNoPrioritarioByServicio(js.getModulo());

                if (!listTurnosPrioritarios.isEmpty()) {
                    //Asignarle turno al modulo  y Cambiar el estado del turno                  
                    updateTurno(js.getModulo().getNum_modulo(), listTurnosPrioritarios.get(0).getId_turno());
                    //Cambiuar el estado del modulo
                    ControlAsignacionTurno ct = new ControlAsignacionTurno();
                    ct.updateEstadoModulo("OCUPADO", js.getModulo().getNum_modulo());
                    validarCurrentActual();
                } else if (!listTurnosNoPrioritarios.isEmpty()) {
                    //Asignarle turno al modulo  y Cambiar el estado del turno                  
                    updateTurno(js.getModulo().getNum_modulo(), listTurnosNoPrioritarios.get(0).getId_turno());
                    //Cambiuar el estado del modulo
                    ControlAsignacionTurno ct = new ControlAsignacionTurno();
                    ct.updateEstadoModulo("OCUPADO", js.getModulo().getNum_modulo());
                    validarCurrentActual();
                } else {
                    IO.mostrar("No hay turnos pendientes para usted.");
                }

            }
        }

    }

    public void actionUpdateTurn() {

    }

    public boolean validarCurrentActual() {

        Turno turno = getCurrentTurn(js.getModulo().getNum_modulo());

        if (turno != null) {

            js.Txtidcliente.setText(turno.getCedula_cliente());
            js.TxtTurnocliente.setText(turno.getId_turno());
            js.TxtTiposervicio.setText(turno.getDescripcion());
            return true;
        } else {
            js.Txtidcliente.setText("");
            js.TxtTurnocliente.setText("");
            js.TxtTiposervicio.setText("");
            return false;
        }

    }

    public List<Turno> getListPrioritarioByServicio(Modulo modulo) {

        List<Turno> listResult = new ArrayList<>();
        try {
            cn.conectar();
            String sql = "select * from turnos where upper(descripcion_turno) = '" + modulo.getCod_servicio().toUpperCase() + "' and upper(prioritario) = 'SI' and upper(estadoturno) = 'PENDIENTE' order by ID_TURNO asc";
            cn.getBD(sql);
            while (cn.getRegistro().next()) {
                Turno turno = new Turno();
                turno.setCedula_cliente(cn.getRegistro().getString("ID_CLIENTE"));
                turno.setId_turno(cn.getRegistro().getString("ID_TURNO"));
                turno.setDescripcion(cn.getRegistro().getString("DESCRIPCION_TURNO"));
                listResult.add(turno);

            }

            cn.CerrarConexion();
            return listResult;
        } catch (Exception e) {
            return listResult;
        }

    }

    public void updateTurno(String codModulo, String idTurno) {

        try {
            cn.conectar();
            String sql = "update turnos set cod_modulo='" + codModulo + "' , estadoturno = 'ASIGNADO' where id_turno='" + idTurno + "' ";
            cn.ejecutar(sql);

            cn.CerrarConexion();

        } catch (Exception e) {

        }

    }
    
     public void updateTurnoFree(String idTurno) {

        try {
            cn.conectar();
            String sql = "update turnos set estadoturno='TERMINADO' where id_turno='" + idTurno + "' ";
            cn.ejecutar(sql);

            cn.CerrarConexion();

        } catch (Exception e) {

        }

    }

    public List<Turno> getListNoPrioritarioByServicio(Modulo modulo) {

        List<Turno> listResult = new ArrayList<>();
        try {
            cn.conectar();
            String sql = "select * from turnos where upper(descripcion_turno) = '" + modulo.getCod_servicio().toUpperCase() + "' and upper(prioritario) = 'NO' and upper(estadoturno) = 'PENDIENTE' order by ID_TURNO  asc";
            cn.getBD(sql);
            while (cn.getRegistro().next()) {
                Turno turno = new Turno();
                turno.setCedula_cliente(cn.getRegistro().getString("ID_CLIENTE"));
                turno.setId_turno(cn.getRegistro().getString("ID_TURNO"));
                turno.setDescripcion(cn.getRegistro().getString("DESCRIPCION_TURNO"));
                listResult.add(turno);

            }

            cn.CerrarConexion();
            return listResult;
        } catch (Exception e) {
            return listResult;
        }

    }

    public Turno getCurrentTurn(String codModulo) {

        Turno turno = null;
        try {
            cn.conectar();
            String sql = "select * from turnos where cod_modulo = '" + codModulo + "' and UPPER(estadoturno) = 'ASIGNADO'";
            cn.getBD(sql);
            if (cn.getRegistro().next()) {
                turno = new Turno();
                turno.setCedula_cliente(cn.getRegistro().getString("ID_CLIENTE"));
                turno.setId_turno(cn.getRegistro().getString("ID_TURNO"));
                turno.setDescripcion(cn.getRegistro().getString("DESCRIPCION_TURNO"));
                return turno;

            }

            cn.CerrarConexion();
            return turno;
        } catch (Exception e) {
            return turno;
        }

    }

    public Modulo getCurrentModule(String codEmpleado) {
        Modulo modulo = null;
        try {
            cn.conectar();
            String sql = "select * from modulos where cod_empleado = '" + codEmpleado + "' ";
            cn.getBD(sql);
            if (cn.getRegistro().next()) {
                modulo = new Modulo();
                modulo.setNum_modulo(cn.getRegistro().getString("NUM_MODULO"));
                modulo.setCod_servicio(cn.getRegistro().getString("COD_SERVICIO"));
                modulo.setEstado(cn.getRegistro().getString("ESTADOMODULO"));

            }

            cn.CerrarConexion();
            return modulo;
        } catch (Exception e) {
            return modulo;
        }
    }

}
