package control;

import vista.JFAsignacionTurno;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import modelo.Turno;
import vista.*;

public class ControlAsignacionTurno implements ActionListener {

    BD cn;
    Turno turno;

    JFAsignacionTurno jfturno;
    JFMostrarTurno jmc = new JFMostrarTurno();

    @SuppressWarnings("LeakingThisInConstructor")

    public ControlAsignacionTurno(JFAsignacionTurno jfturno) {
        cn = new BD();

        this.jfturno = jfturno;

        jfturno.Bcrear.addActionListener(this);
        jfturno.Bvolver.addActionListener(this);

    }

    public ControlAsignacionTurno() {
        cn = new BD();
    }
    

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == jfturno.Bvolver) {

            jfturno.dispose();
        }
        if (e.getSource() == jfturno.Bcrear) {
            ControlJFRegistroCliente clienteServices = new ControlJFRegistroCliente();
            if (null == clienteServices.findUserByDocumento(jfturno.Tnumero.getText())) {
                IO.mostrar("Debe Ser Cliente Para Poder Ser Atendido");
            } else {
                Turno turno = new Turno();

                turno.setCedula_cliente(jfturno.Tnumero.getText());
                SimpleDateFormat d = new SimpleDateFormat("dd-MM-yy");
                Date fecha = new Date();

                turno.setHora(getHoraActual());
                turno.setDescripcion(jfturno.tipoServicio.getSelectedItem().toString());
                turno.setPrioritario(jfturno.isPrioritario.getSelectedItem().toString());

                createTurno(turno);
            }

        }

    }

    public String getHoraActual() {
        Calendar calendario = Calendar.getInstance();
        int hora, minutos, segundos;
        hora = calendario.get(Calendar.HOUR_OF_DAY);
        minutos = calendario.get(Calendar.MINUTE);
        segundos = calendario.get(Calendar.SECOND);
        return (hora + ":" + minutos + ":" + segundos);
    }

    public void createTurno(Turno turno) {
        try {
            cn.conectar();
            //Asignar id
            turno.setId_turno(String.valueOf(getSeqTurnos()));

//Obtener modulos disponibles.
            List<String> modulosFree = getModulosFreeByServicio(turno.getDescripcion());

            if (!modulosFree.isEmpty()) {
                Random rand = new Random();
                String modulo = modulosFree.get(rand.nextInt(modulosFree.size()));
                String sql = "insert into turnos (ID_TURNO,HORA_INICIO_TURNO,DESCRIPCION_TURNO,COD_MODULO,ID_CLIENTE,ESTADOTURNO,PRIORITARIO) "
                        + "values('" + turno.getId_turno() + "' , '" + turno.getHora() + "', '" + turno.getDescripcion() + "', '" + modulo + "', '" + turno.getCedula_cliente() + "','ASIGNADO' ,'" + turno.getPrioritario() + "' )";

                System.out.println(sql);
                IO.mostrar("Pase al siguiente modulo " + modulo);
                cn.ejecutar(sql);
                //Actualizar el modulo a asignado
                updateEstadoModulo("OCUPADO", modulo);

            } else {
                String sql = "insert into turnos (ID_TURNO,HORA_INICIO_TURNO,DESCRIPCION_TURNO,ID_CLIENTE,ESTADOTURNO,PRIORITARIO) "
                        + "values('" + turno.getId_turno() + "' ,  '" + turno.getHora() + "', '" + turno.getDescripcion() + "',  '" + turno.getCedula_cliente() + "','PENDIENTE' , '" + turno.getPrioritario() + "' )";
                cn.ejecutar(sql);
                IO.mostrar("no hay asesores disponibles, su turno es " + turno.getId_turno());
                System.out.println(sql);

            }
            cn.CerrarConexion();
        } catch (Exception e) {

        }

    }

    public boolean deleteTurno(String id_turno) {
        Turno turno = null;
        try {

            String sql = "delete from turnos where id_ turno= '" + id_turno + "' ";
            cn.conectar();
            boolean result = cn.ejecutar(sql);

            cn.CerrarConexion();

            return result;

        } catch (SQLException ex) {
            Logger.getLogger(ControlAsignacionTurno.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public int getSeqTurnos() {
        int result = 0;
        try {
            String sql = "select seq_turnos.nextval id from dual";

            cn.conectar();
            cn.getBD(sql);
            cn.getRegistro().next();
            result = cn.getRegistro().getInt("id");
            cn.CerrarConexion();
        } catch (Exception e) {
            System.out.println("Error " + e.getMessage());
        }
        return result;
    }

    public boolean updateEstadoModulo(String estado, String id_modulo) {

        try {
            String sql = "update modulos set estadomodulo = '" + estado.toUpperCase() + "' where upper(num_modulo) = '" + id_modulo + "' ";

            cn.conectar();
            cn.ejecutar(sql);
            cn.CerrarConexion();
            return true;

        } catch (Exception e) {
            System.out.println("Error updateEstadoModulo" + e.getMessage());
            return false;
        }

    }

    public List<String> getModulosFreeByServicio(String servicio) {
        List<String> result = new ArrayList<>();
        try {
            String sql = "select NUM_MODULO ID from MODULOS where cod_servicio = '" + servicio + "' and upper(estadomodulo) = 'LIBRE'";

            cn.conectar();
            cn.getBD(sql);
            while (cn.getRegistro().next()) {
                result.add(cn.getRegistro().getString("ID"));
            }
            cn.CerrarConexion();
        } catch (Exception e) {
            System.out.println("Error " + e.getMessage());
        }
        return result;
    }

}
