
package control;
import vista.JFPrioritario;
import vista.JFMostrarTurno;
import java.awt.event.*;
import java.sql.*;
import control.BD;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.Timer;
import java.text.DateFormat;

import modelo.*;
import vista.*;

public class ControlJFPrioritario implements ActionListener{
     
    private int cajapriotaria;
    private int asprioritaria;
    private int tp;
    private int pa;
    JFPrioritario jfp;
     JFAsignacionTurno jfturno;
     JFMostrarTurno jmc= new JFMostrarTurno(); 
    
          
    @SuppressWarnings("LeakingThisInConstructor")

    public ControlJFPrioritario( JFPrioritario jfturnoprio) {
   
       
        this.jfp = jfturnoprio;
        this.tp=tp;
        this.pa=pa;
        
         jfturnoprio.Basesoriaprioritaria.addActionListener(this);
          jfturnoprio.Bcajaprioritaria.addActionListener(this);
            jfturnoprio.Bvolver.addActionListener(this);
}
 @Override
    public void actionPerformed(ActionEvent e) {
            
          
          if (e.getSource() == jfp.Bcajaprioritaria) {
            ControlJFMostrarTurno cmc  = new ControlJFMostrarTurno(jmc);
        jmc.setVisible(true);
        jmc.setLocationRelativeTo(null);
        
        
         String secuencia="";
            tp=tp+1;
            secuencia=  "" + tp;
            
            jmc.TxtidCajaturno.setText(secuencia);
            
        
            String myDate = "";
            String CajaPriotaria = " ";
            String cadena = "CP";
            cajapriotaria = cajapriotaria+ 1;

            CajaPriotaria = ("CP" + cajapriotaria);

            jmc.Txtrecibirturno.setText((CajaPriotaria));

            Date sistFecha = new Date();
            SimpleDateFormat formato = new SimpleDateFormat("dd MMMM YYYY");
            jmc.Tfecha.setText(formato.format(sistFecha));

            Date sistHora = new Date();
            String pmAm = "hh : mm :  ss a";
            SimpleDateFormat format = new SimpleDateFormat(pmAm);
            Calendar hoy = Calendar.getInstance();
            jmc.Thora.setText(String.format(format.format(sistHora), hoy));
        
           }
          if(e.getSource()==jfp.Basesoriaprioritaria){
              ControlJFMostrarTurno cmc  = new ControlJFMostrarTurno(jmc);
        jmc.setVisible(true);
        jmc.setLocationRelativeTo(null);
        
         String secuencia="";
            pa=pa+1;
            secuencia=  "" + pa;
            
            jmc.TxtidCajaturno.setText(secuencia);
            
        
        
            String myDate = "";
            String AsesoriaPriotaria = " ";
            String cadena = "AP";
            asprioritaria = asprioritaria+ 1;

            AsesoriaPriotaria = ("AP" + asprioritaria);

            jmc.Txtrecibirturno.setText((AsesoriaPriotaria));

            Date sistFecha = new Date();
            SimpleDateFormat formato = new SimpleDateFormat("dd MMMM YYYY");
            jmc.Tfecha.setText(formato.format(sistFecha));

            Date sistHora = new Date();
            String pmAm = "hh : mm :  ss a";
            SimpleDateFormat format = new SimpleDateFormat(pmAm);
            Calendar hoy = Calendar.getInstance();
            jmc.Thora.setText(String.format(format.format(sistHora), hoy));
              
          }
         if (e.getSource() ==  jfp.Bvolver) {

            jfp.dispose();
         
    }
    }
}
