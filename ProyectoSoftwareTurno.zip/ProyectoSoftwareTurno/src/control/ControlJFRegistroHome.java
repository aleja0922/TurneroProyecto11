package control;

import modelo.*;
import vista.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import vista.JFRegistroHome;
import vista.JFAsignacionTurno;
import control.ControlJFModuloEstadoTurno;

public class ControlJFRegistroHome implements ActionListener {

    JFRegistroHome jhome;
    JFMostrarTurno jms = new JFMostrarTurno();
    JFAsesoria jfa = new JFAsesoria();

    Turno turno = new Turno();
    Cliente cliente = new Cliente();
    JFRegistroCliente jfrcliente = new JFRegistroCliente();
    JFAsignacionTurno jfturno = new JFAsignacionTurno();
    JFMostrarCliente m = new JFMostrarCliente();

    @SuppressWarnings("LeakingThisInConstructor")
    public ControlJFRegistroHome(JFRegistroHome jhome) {

        this.jhome = jhome;
        this.jfturno = jfturno;
        this.jms = jms;

        jhome.Bregistrocliente.addActionListener(this);
        jhome.Bmostrar.addActionListener(this);
        jhome.BEstadoTurno.addActionListener(this);
        jhome.Bsalir.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == jhome.Bregistrocliente) {
            ControlJFRegistroCliente cjfrcliente = new ControlJFRegistroCliente(cliente, jfrcliente);
            jfrcliente.setVisible(true);
            jfrcliente.setLocationRelativeTo(null);

        }
        if (e.getSource() == jhome.BEstadoTurno) {

            JFModuloEstadoTurno js = new JFModuloEstadoTurno(jhome.getAsesor());
            ControlJFModuloEstadoTurno cet = new ControlJFModuloEstadoTurno(js);
            js.setVisible(true);
            js.setLocationRelativeTo(null);

            js.Txtidcliente.setVisible(true);
            js.TxtTurnocliente.setVisible(true);
            js.TxtTiposervicio.setVisible(true);

            jms.Txtrecibirturno.setText(js.TxtTurnocliente.getText());
        }
        if (e.getSource() == jhome.Bsalir) {
            jhome.dispose();
        }
        if (e.getSource() == jhome.Bmostrar) {
            ControlJFMostrarClientes c = new ControlJFMostrarClientes(m);

            m.setVisible(true);
            m.setTitle("MI TURNERO");
            m.setLocationRelativeTo(null);

        }
    }

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
