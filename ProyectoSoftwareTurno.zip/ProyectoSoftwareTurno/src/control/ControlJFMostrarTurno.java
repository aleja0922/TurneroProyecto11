
package control;

import modelo.*;
import vista.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlJFMostrarTurno implements ActionListener{
        
    JFMostrarTurno jmc;
    
    @SuppressWarnings("LeakingThisInConstructor")

    public ControlJFMostrarTurno(JFMostrarTurno jmc ) {
          
        this.jmc=jmc;
        
            
        jmc.Bsalir.addActionListener(this);
        
        
    }

    
    @Override
    public void actionPerformed(ActionEvent e) {
        
     if (e.getSource() == jmc.Bsalir) {
        
        
           jmc.dispose();
        }
      
               
           
    }
}
     

    





